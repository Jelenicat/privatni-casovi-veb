import { google } from 'googleapis';
import applyCors from '../utils/cors.js';

export default async function handler(req, res) {
  const isPreflight = applyCors(req, res);
  if (isPreflight) return;

  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Only POST method is allowed' });
  }

  try {
    const auth = new google.auth.JWT(
      process.env.GOOGLE_CLIENT_EMAIL,
      null,
      process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
      ['https://www.googleapis.com/auth/calendar']
    );

    await auth.authorize();
    const calendar = google.calendar({ version: 'v3', auth });

    const { ime, prezime, email, datum, vreme } = req.body;
    const start = new Date(`${datum}T${vreme}:00`);
    const end = new Date(start.getTime() + 60 * 60 * 1000);

    const event = {
      summary: `Čas sa ${ime} ${prezime}`,
      description: 'Privatni čas zakazan putem aplikacije.',
      start: { dateTime: start.toISOString(), timeZone: 'Europe/Belgrade' },
      end: { dateTime: end.toISOString(), timeZone: 'Europe/Belgrade' },
      attendees: [{ email }],
      conferenceData: {
        createRequest: {
          requestId: `${Date.now()}`,
          conferenceSolutionKey: { type: 'hangoutsMeet' },
        },
      },
    };

    const result = await calendar.events.insert({
      calendarId: process.env.GOOGLE_CLIENT_EMAIL,
      resource: event,
      conferenceDataVersion: 1,
    });

    return res.status(200).json({ hangoutLink: result.data?.hangoutLink });
  } catch (error) {
    console.error('❌ GRESKA u create-meet:', error);
    return res.status(500).json({ error: 'Greška prilikom kreiranja Google Meet linka', detalji: error.message });
  }
}
